﻿using System;
using System.Threading;

class Algoshit3
{
    private string input;

    public Algoshit3(string userInput)
    {
        input = userInput;
    }

    public void Process_3()
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine("Processing Bitwise XOR Cipher with input: " + input);
        Console.ResetColor();
        Console.Clear();

        Console.Write("Enter a numeric key: ");
        if (!int.TryParse(Console.ReadLine(), out int key)) 
        {
            Console.WriteLine("Invalid key. Please enter a number.");
            return;
        }

        string encrypted = XORCipher(input, key);
        Console.WriteLine("Encrypted: " + encrypted);

        string decrypted = XORCipher(encrypted, key);

        while (true)
        {
            Console.WriteLine("Press 'D' to decrypt or 'C' to continue: ");
            string validation = Console.ReadLine()?.Trim().ToLower();

            if (validation == "d")
            {
                Console.WriteLine("Decrypted: " + decrypted);
                Console.ResetColor();
                break;
            }
            else if (validation == "c")
            {
                break;
            }
            else
            {
                Console.WriteLine("Invalid input. Please enter 'D' to decrypt or 'C' to continue.");
            }
        }
        while (true)
        {
            Console.WriteLine("Do you want to go back to the main menu? (Y/N)");
            string response = Console.ReadLine().Trim().ToLower();

            if (response == "y")
            {
                return;
            }   
            else if (response == "n")
            {
                Console.Clear();
                Program.Main();
                return;
            }
            else
                Console.WriteLine("Invalid input. Please enter 'Y' to return or 'N' to continue.");
        }
    }
    private string XORCipher(string text, int key)
    {
        char[] result = new char[text.Length];

        for (int i = 0; i < text.Length; i++)
        {
            result[i] = (char)(text[i] ^ key);
        }

        return new string(result);
    }
}
