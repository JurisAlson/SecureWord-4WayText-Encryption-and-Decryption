﻿using System;
using System.Threading;

class Algoshit1
{
    private string input;
    private const int Shifting = 3;

    public Algoshit1(string userInput)
    {
        input = userInput;
    }

    public void Process_1()
    {
        Console.WriteLine("Processing Caesar Cipher....");
        Thread.Sleep(2000);
        Console.WriteLine("Processing Caesar Cipher...");
        Thread.Sleep(2000);
        Console.WriteLine("Processing Caesar Cipher..");
        Console.Clear();

        Console.ForegroundColor = ConsoleColor.Cyan;
        string encrypted = Encrypt(input);

        Console.WriteLine($"Original: {input}\n");
        Console.WriteLine($"Encrypted: {encrypted}");

        string decrypted = Decrypt(encrypted); 

        while (true)
        {
            Console.WriteLine("Press 'D' to decrypt or 'C' to continue:");
            string validation = Console.ReadLine()?.Trim().ToUpper();

            if (validation == "D")
            {
                Console.WriteLine($"Decrypted: {decrypted}");
                Console.ResetColor();
                break; 
            }
            else if (validation == "C")
            {
                break; 
            }
            else
            {
                Console.WriteLine("Invalid input. Please enter 'D' to decrypt or 'C' to continue.");
            }
        }

        while (true)
        {
            Console.WriteLine("Do you want to go back to the main menu? (Y/N)");
            string response = Console.ReadLine()?.Trim().ToLower();

            if (response == "y")
            {
                Console.Clear();
                Program.Main(); 
                return;
            }
            else if (response == "n")
            {
                Console.WriteLine("Continuing process...");
                break; 
            }
            else
            {
                Console.WriteLine("Invalid input. Please enter 'Y' to return or 'N' to continue.");
            }
        }
    }

    private static string Encrypt(string text)
    {
        return Process(text, Shifting);
    }

    private static string Decrypt(string text)
    {
        return Process(text, -Shifting);
    }

    private static string Process(string text, int shift)
    {
        char[] buffer = text.ToCharArray();
        for (int i = 0; i < buffer.Length; i++)
        {
            char letter = buffer[i];

            if (char.IsLetter(letter))
            {
                char baseChar = char.IsUpper(letter) ? 'A' : 'a';
                buffer[i] = (char)((letter - baseChar + shift + 26) % 26 + baseChar);
            }
        }
        return new string(buffer);
    }
}
