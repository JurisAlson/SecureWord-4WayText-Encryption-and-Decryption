﻿class Algoshit4
{
    private string input;

    public Algoshit4(string userInput)
    {
        input = userInput;
    }

    public void Process_4()
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine("Processing Algoshit 4 with input: " + input + "uLOL MO");
        Console.ResetColor();

        while (true)
        {
            Console.WriteLine("Do you want to go back to the main menu? (Y/N)");
            string response = Console.ReadLine().Trim().ToLower();

            if (response == "y")
                return;
            else if (response == "n")
                Console.WriteLine("Continuing process...");
            else
                Console.WriteLine("Invalid input. Please enter 'Y' to return or 'N' to continue.");
        }
    }
}