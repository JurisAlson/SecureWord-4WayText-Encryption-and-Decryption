﻿using System;
using System.Linq;
using System.Threading;

class Program
{

    public static void Main()
    {
        Console.ForegroundColor = ConsoleColor.Green;

        string userInput;
        while (true)
        {
            Console.Write("Enter a string (only A-Z, a-z allowed): ");
            userInput = Console.ReadLine();

            if (!userInput.All(char.IsLetter))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Invalid input! Only letters (A-Z, a-z) are allowed.");
                Console.ForegroundColor = ConsoleColor.Green;
                continue;
            } 

            if(userInput.Length > 6)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Error: Input exceeds 6 characters. Please try again.");
                Console.ForegroundColor = ConsoleColor.Green;
                continue;
            }
            if (userInput.Length < 6)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Error: Input MUST be atleast 6 characters. Please try again.");
                Console.ForegroundColor = ConsoleColor.Green;
                continue;
            }
            break;
        }
        Console.Clear();
        while (true)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("You entered: " + userInput);
            Console.WriteLine("Select an option:");
            Console.WriteLine("1 - Caesar  ");
            Console.WriteLine("2 - Kama Sutra ");
            Console.WriteLine("3 - Bitwise XOR Cipher ");
            Console.WriteLine("4 - Algoshit 4 ");
            Console.WriteLine("5 - Exit");
            Console.ResetColor();

            Console.Write("Enter your choice (1-5): ");
            if (int.TryParse(Console.ReadLine(), out int choice))
            {
                switch (choice)
                {
                    case 1:
                        Algoshit1 algo1 = new Algoshit1(userInput);
                        algo1.Process_1();
                        Thread.Sleep(2000);
                        break;
                    case 2:
                        Algoshit2 algo2 = new Algoshit2(userInput);
                        algo2.Process_2(); 
                        break;
                    case 3:
                        Algoshit3 algo3 = new Algoshit3(userInput);
                        algo3.Process_3();
                        break;
                    case 4:
                        Algoshit4 algo4 = new Algoshit4(userInput);
                        algo4.Process_4();
                        break;
                    case 5:
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("Exiting program.");
                        Console.ResetColor();
                        return;
                    default:
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Invalid choice. Please enter a number between 1 and 5.");
                        Console.ResetColor();
                        break;
                }
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Invalid input. Please enter a number between 1 and 5.");
                Console.ResetColor();
            }
            Console.Clear();
        }
    }
}
